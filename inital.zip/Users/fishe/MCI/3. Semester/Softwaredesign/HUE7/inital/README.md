# 🏆 Hausaufgabe: Benchmarking Sortier-Algorithmen auf 2 PCs

## Aufgabenstellung

- [Link](https://mrp123.github.io/MCI-MECH-B-3-SWD-SWD-ILV/02_Versionsverwaltung_und_Git/02_02_Versionsverwaltung_und_Git.html#29)

## Requirements

- Der Code erfordert keine speziellen Bibliotheken.

## Ausführung

- Mit `random_gen.py` können bei Bedarf neue Testdaten in die Datei `random.txt` geschrieben werden.
- Die Datei `test.py` führt den Benchmark aus und schreibt die Ergebnisse in die Datei `results.txt`.